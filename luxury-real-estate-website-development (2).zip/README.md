# Prestige Homes

A premium real-estate platform built with Next.js App Router, TypeScript, PostgreSQL, and Drizzle ORM. It includes curated property discovery, location and property filters, saved/compare interactions, detailed listing pages, inquiry capture, an account experience, and an advisor dashboard UI.

> **Hosting note:** This project uses Next.js route handlers and PostgreSQL for inquiry capture. It is ready to publish on GitHub and deploy from GitHub to a server-capable platform such as Vercel, Render, Railway, or Fly.io. It cannot be deployed as a fully functional static GitHub Pages site because GitHub Pages does not run server APIs or PostgreSQL.

## Technology

- Next.js 16 with App Router and React 19
- TypeScript and Tailwind CSS v4
- PostgreSQL with Drizzle ORM
- GitHub Actions CI

## Local setup

### Prerequisites

- Node.js 22 or newer
- npm 10 or newer
- PostgreSQL 16 or newer

### Install and run

1. Clone the repository and install dependencies:

   ```bash
   git clone https://github.com/YOUR-USERNAME/prestige-homes.git
   cd prestige-homes
   npm ci
   ```

2. Create a local environment file from the safe template:

   ```bash
   cp .env.example .env
   ```

3. Update `DATABASE_URL` in `.env` with your PostgreSQL connection string. For a local default PostgreSQL instance, it can resemble:

   ```text
   DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/prestige_homes
   ```

4. Apply the schema and start the development server:

   ```bash
   npx drizzle-kit push
   npm run dev
   ```

Open [http://localhost:3000](http://localhost:3000).

## Database

The Drizzle schema is maintained in `src/db/schema.ts` and currently contains:

- `properties` — property listing records
- `inquiries` — messages submitted from property and contact forms
- `saved_properties` — a persistence-ready saved-listing model

After any schema change, run:

```bash
npx drizzle-kit push
```

## Quality checks

Run these checks before opening a pull request:

```bash
npx next typegen
npm exec tsc -- --noEmit --pretty false
npm run build
```

The GitHub Actions workflow runs these checks automatically against a temporary PostgreSQL service on every push and pull request.

## Publish to GitHub

1. Create a new empty repository named `prestige-homes` in your GitHub account.
2. From this project folder, initialize and push the repository:

   ```bash
   git init
   git add .
   git commit -m "Initial Prestige Homes release"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/prestige-homes.git
   git push -u origin main
   ```

3. Open the **Actions** tab on GitHub to confirm the `Verify` workflow completes successfully.

The included `.gitignore` prevents `.env`, build output, dependency folders, logs, and local hosting artifacts from being committed. Never commit a live database URL.

## Deploy from GitHub to Vercel

1. Push this repository to GitHub.
2. In [Vercel](https://vercel.com/new), select **Import Git Repository** and choose `prestige-homes`.
3. Add these environment variables in Vercel Project Settings:
   - `DATABASE_URL` — the production PostgreSQL connection string
   - `NEXT_PUBLIC_SITE_URL` — your final public URL, such as `https://prestigehomes.com`
4. Before accepting inquiries, apply the production schema once using the same production `DATABASE_URL`:

   ```bash
   npx drizzle-kit push
   ```

5. Deploy. Future pushes to `main` will generate production deployments; pull requests generate previews.

For secure automated database updates, store a production connection string as a GitHub Actions secret and use a separate release workflow. Do not put database credentials in source files or repository variables.

## Available routes

- `/` — home and featured residences
- `/properties` — collection with filters, location selection, sorting, and views
- `/property/[slug]` — property details, gallery, advisor, and inquiry form
- `/about`, `/services`, `/agents`, `/testimonials`, `/blog`, `/contact`
- `/login`, `/register`, `/dashboard`
- `/api/inquiries` — PostgreSQL-backed inquiry submission endpoint
- `/api/health` — deployment health endpoint

## License

This project is provided for private use and evaluation. Replace this section with your preferred license before publishing it as an open-source project.
