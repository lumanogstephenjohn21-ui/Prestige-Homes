import type { Metadata } from "next";
import { notFound } from "next/navigation";
import PrestigeSite from "@/components/prestige-site";

const pages = ["about", "services", "agents", "testimonials", "blog", "contact", "login", "register", "dashboard"] as const;
type SupportedPage = (typeof pages)[number];

const pageMeta: Record<SupportedPage, Metadata> = {
  about: { title: "Our Story | Prestige Homes", description: "Meet the people and principles behind Prestige Homes." },
  services: { title: "Services | Prestige Homes", description: "Personal real estate advisory for exceptional homes and ambitious moves." },
  agents: { title: "Our Advisors | Prestige Homes", description: "Meet Prestige Homes' trusted luxury property advisors." },
  testimonials: { title: "Client Stories | Prestige Homes", description: "Read stories from Prestige Homes clients." },
  blog: { title: "The Prestige Journal", description: "Ideas on property, place, design, and exceptional living." },
  contact: { title: "Contact | Prestige Homes", description: "Start a conversation with Prestige Homes." },
  login: { title: "Sign In | Prestige Homes", robots: { index: false } },
  register: { title: "Create Account | Prestige Homes", robots: { index: false } },
  dashboard: { title: "Advisor Dashboard | Prestige Homes", robots: { index: false } },
};

export async function generateMetadata({ params }: { params: Promise<{ page: string }> }): Promise<Metadata> {
  const { page } = await params;
  return pages.includes(page as SupportedPage) ? pageMeta[page as SupportedPage] : {};
}

export default async function SupportingPage({ params }: { params: Promise<{ page: string }> }) {
  const { page } = await params;
  if (!pages.includes(page as SupportedPage)) notFound();
  return <PrestigeSite page={page as SupportedPage} />;
}
