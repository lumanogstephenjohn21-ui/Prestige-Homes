import type { Metadata } from "next";
import PrestigeSite from "@/components/prestige-site";

export const metadata: Metadata = {
  title: "Luxury Properties | Prestige Homes",
  description: "Explore a considered collection of remarkable homes in the world's most desirable places.",
};

export default function PropertiesPage() {
  return <PrestigeSite page="properties" />;
}
