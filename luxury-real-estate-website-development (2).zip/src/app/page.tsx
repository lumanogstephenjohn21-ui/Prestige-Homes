import PrestigeSite from "@/components/prestige-site";

export default function HomePage() {
  return <PrestigeSite page="home" />;
}
