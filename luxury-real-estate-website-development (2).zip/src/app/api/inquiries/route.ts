import { db } from "@/db";
import { inquiries } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim() : "";
    const message = typeof body.message === "string" ? body.message.trim() : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : null;
    const propertySlug = typeof body.propertySlug === "string" ? body.propertySlug.trim() : null;

    if (!name || !email || !message || !/^\S+@\S+\.\S+$/.test(email)) {
      return Response.json({ error: "Please provide a name, valid email, and message." }, { status: 400 });
    }

    await db.insert(inquiries).values({
      name: name.slice(0, 120),
      email: email.slice(0, 180),
      phone: phone?.slice(0, 60) || null,
      propertySlug: propertySlug?.slice(0, 160) || null,
      message: message.slice(0, 5000),
    });

    return Response.json({ ok: true }, { status: 201 });
  } catch {
    return Response.json({ error: "Unable to send inquiry." }, { status: 500 });
  }
}
