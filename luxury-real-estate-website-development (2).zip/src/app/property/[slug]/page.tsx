import type { Metadata } from "next";
import { notFound } from "next/navigation";
import PrestigeSite from "@/components/prestige-site";
import { properties } from "@/data/prestige-data";

export function generateStaticParams() {
  return properties.map((property) => ({ slug: property.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const property = properties.find((item) => item.slug === slug);
  if (!property) return {};
  return {
    title: `${property.title} | Prestige Homes`,
    description: `${property.beds}-bedroom ${property.type.toLowerCase()} in ${property.location}.`,
    openGraph: { images: [{ url: property.image }] },
  };
}

export default async function PropertyDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const property = properties.find((item) => item.slug === slug);
  if (!property) notFound();
  return <PrestigeSite page="detail" property={property} />;
}
