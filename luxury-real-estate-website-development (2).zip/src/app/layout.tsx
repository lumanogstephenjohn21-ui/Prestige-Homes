import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://prestigehomes.example";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Prestige Homes | Exceptional Homes, Thoughtfully Matched",
    template: "%s | Prestige Homes",
  },
  description: "A considered collection of remarkable residences, matched with the people who will cherish them.",
  keywords: ["luxury real estate", "premium homes", "property advisor", "Prestige Homes"],
  openGraph: {
    type: "website",
    siteName: "Prestige Homes",
    title: "Prestige Homes | Exceptional Homes, Thoughtfully Matched",
    description: "A considered collection of remarkable residences, matched with the people who will cherish them.",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
