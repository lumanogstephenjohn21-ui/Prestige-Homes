export type Property = {
  slug: string;
  title: string;
  location: string;
  neighborhood: string;
  type: string;
  price: string;
  numericPrice: number;
  beds: number;
  baths: number;
  area: string;
  image: string;
  gallery: string[];
  label: string;
  description: string;
  features: string[];
  amenities: string[];
  agent: string;
};

export const locationOptions = [
  { value: "", label: "All locations" },
  { value: "Malibu", label: "Malibu, California" },
  { value: "Beverly Hills", label: "Beverly Hills, California" },
  { value: "New York", label: "New York, New York" },
  { value: "Miami Beach", label: "Miami Beach, Florida" },
  { value: "Aspen", label: "Aspen, Colorado" },
  { value: "Los Angeles", label: "Los Angeles, California" },
];

export const properties: Property[] = [
  {
    slug: "the-pacific-residence",
    title: "The Pacific Residence",
    location: "Malibu, California",
    neighborhood: "Carbon Beach",
    type: "Villa",
    price: "$12,850,000",
    numericPrice: 12850000,
    beds: 5,
    baths: 6,
    area: "6,240 sq ft",
    image: "https://images.pexels.com/photos/31817157/pexels-photo-31817157.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    gallery: [
      "https://images.pexels.com/photos/31817157/pexels-photo-31817157.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
      "https://images.pexels.com/photos/10610731/pexels-photo-10610731.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900",
      "https://images.pexels.com/photos/36676879/pexels-photo-36676879.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900",
      "https://images.pexels.com/photos/16959786/pexels-photo-16959786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
    ],
    label: "Signature Collection",
    description: "A serene coastal compound where sculptural architecture meets the endless Pacific horizon. Impeccably composed for effortless indoor-outdoor living, the home offers intimate family spaces alongside spectacular entertaining terraces.",
    features: ["Oceanfront position", "Floor-to-ceiling glass", "Gourmet chef’s kitchen", "Primary suite with terrace", "Climate-controlled wine room", "Three-car gallery garage"],
    amenities: ["Infinity edge pool", "Private beach access", "Smart home control", "Cinema room", "Wellness studio", "24-hour security"],
    agent: "Eleanor Hart"
  },
  {
    slug: "atrium-house",
    title: "Atrium House",
    location: "Beverly Hills, California",
    neighborhood: "Trousdale Estates",
    type: "House",
    price: "$9,400,000",
    numericPrice: 9400000,
    beds: 4,
    baths: 5,
    area: "4,880 sq ft",
    image: "https://images.pexels.com/photos/10610731/pexels-photo-10610731.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    gallery: [
      "https://images.pexels.com/photos/10610731/pexels-photo-10610731.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
      "https://images.pexels.com/photos/16959786/pexels-photo-16959786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
    ],
    label: "New to Market",
    description: "A warm modernist residence defined by a leafy central atrium and luminous, gallery-like interiors. Every material has been selected to balance refined design with an easy California rhythm.",
    features: ["Architect-designed", "Sunken lounge", "Italian kitchen", "Guest casita", "Library", "Motor court"],
    amenities: ["Saltwater pool", "Outdoor kitchen", "Lutron lighting", "Security system", "Mature gardens", "EV charging"],
    agent: "Marcus Vale"
  },
  {
    slug: "skyline-penthouse",
    title: "Skyline Penthouse",
    location: "New York, New York",
    neighborhood: "Tribeca",
    type: "Penthouse",
    price: "$16,900,000",
    numericPrice: 16900000,
    beds: 4,
    baths: 4,
    area: "5,120 sq ft",
    image: "https://images.pexels.com/photos/7031602/pexels-photo-7031602.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    gallery: [
      "https://images.pexels.com/photos/7031602/pexels-photo-7031602.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
      "https://images.pexels.com/photos/36676879/pexels-photo-36676879.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
    ],
    label: "Private Listing",
    description: "Set above Tribeca with cinematic city views, this full-floor penthouse marries soaring proportions with discreet, five-star service. A private elevator opens directly into a home designed for exceptional living.",
    features: ["Full-floor residence", "Private elevator", "Corner great room", "Custom millwork", "Chef’s pantry", "Two terraces"],
    amenities: ["Concierge", "Fitness suite", "Private storage", "Doorman", "Residents’ lounge", "Pet spa"],
    agent: "Sofia Laurent"
  },
  {
    slug: "casa-serena",
    title: "Casa Serena",
    location: "Miami Beach, Florida",
    neighborhood: "Sunset Islands",
    type: "Villa",
    price: "$8,750,000",
    numericPrice: 8750000,
    beds: 6,
    baths: 7,
    area: "5,730 sq ft",
    image: "https://images.pexels.com/photos/36676879/pexels-photo-36676879.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    gallery: [
      "https://images.pexels.com/photos/36676879/pexels-photo-36676879.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
      "https://images.pexels.com/photos/29560257/pexels-photo-29560257.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
    ],
    label: "Waterfront",
    description: "A tropical modern hideaway built around tranquil water views and soft, sun-washed spaces. The home brings resort-style privacy to one of Miami’s most sought-after island addresses.",
    features: ["Waterfront setting", "Double-height entry", "Designer interiors", "Guest wing", "Summer kitchen", "Dock access"],
    amenities: ["Heated pool", "Spa", "Boat dock", "Media lounge", "Gated entry", "Generator"],
    agent: "Eleanor Hart"
  },
  {
    slug: "oakridge-estate",
    title: "Oakridge Estate",
    location: "Aspen, Colorado",
    neighborhood: "Red Mountain",
    type: "Estate",
    price: "$14,200,000",
    numericPrice: 14200000,
    beds: 7,
    baths: 8,
    area: "9,100 sq ft",
    image: "https://images.pexels.com/photos/16959786/pexels-photo-16959786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    gallery: [
      "https://images.pexels.com/photos/16959786/pexels-photo-16959786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
      "https://images.pexels.com/photos/7031602/pexels-photo-7031602.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
    ],
    label: "Mountain Retreat",
    description: "An enduring mountain estate with uncompromised craftsmanship, wide-open alpine views, and quiet proximity to Aspen’s cultural heart. A legacy home for all seasons.",
    features: ["Mountain views", "Reclaimed timber beams", "Stone fireplaces", "Ski room", "Staff apartment", "Heated drive"],
    amenities: ["Indoor pool", "Sauna", "Home theater", "Wine cellar", "Gym", "Snow melt system"],
    agent: "Marcus Vale"
  },
  {
    slug: "the-olive-courtyard",
    title: "The Olive Courtyard",
    location: "Los Angeles, California",
    neighborhood: "Los Feliz",
    type: "House",
    price: "$6,980,000",
    numericPrice: 6980000,
    beds: 4,
    baths: 5,
    area: "4,240 sq ft",
    image: "https://images.pexels.com/photos/29560257/pexels-photo-29560257.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    gallery: [
      "https://images.pexels.com/photos/29560257/pexels-photo-29560257.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1600",
      "https://images.pexels.com/photos/31817157/pexels-photo-31817157.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=900"
    ],
    label: "Design Edition",
    description: "A refined hillside home of soft stone, oak, and glass. Framed by mature olive trees, the residence creates an enveloping sense of calm just minutes from the city.",
    features: ["Hillside setting", "Open-plan living", "Art walls", "Breakfast courtyard", "Office", "Two-car garage"],
    amenities: ["Plunge pool", "Outdoor firepit", "Smart home", "Alarm system", "Mediterranean garden", "Sonos audio"],
    agent: "Sofia Laurent"
  }
];

export const agents = [
  { name: "Eleanor Hart", role: "Founding Partner", sales: "$1.2B+ in career sales", image: "https://images.pexels.com/photos/3769021/pexels-photo-3769021.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=420", initial: "EH" },
  { name: "Marcus Vale", role: "Senior Property Advisor", sales: "Top 1% in California", image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=420", initial: "MV" },
  { name: "Sofia Laurent", role: "International Director", sales: "18 years of expertise", image: "https://images.pexels.com/photos/762080/pexels-photo-762080.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=500&w=420", initial: "SL" }
];

export const journal = [
  { category: "Market Intelligence", title: "The art of buying well in 2025’s most coveted enclaves", date: "May 18, 2025", image: properties[2].image },
  { category: "Design", title: "Quiet luxury: materials that define a timeless home", date: "April 29, 2025", image: properties[1].image },
  { category: "Neighborhoods", title: "A discerning guide to the new Malibu", date: "April 10, 2025", image: properties[0].image }
];
